package com.tensei.ytxtube

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Resources
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.unit.LayoutDirection
import java.util.Locale

/**
 * App language: "system" (follow the phone), "en" or "ar".
 *
 * Arabic always uses Western digits (0123456789), never Eastern/Hindi ones (٠١٢٣٤٥٦٧٨٩),
 * so the Java default locale is set to `ar-u-nu-latn`.
 */
object AppLanguage {
    private var prefs: SharedPreferences? = null
    private var originalLocale: Locale = Locale.getDefault()

    /** "system" | "en" | "ar" */
    var choice by mutableStateOf("ar")
        private set

    private val systemIsArabic: Boolean
        get() = Resources.getSystem().configuration.locales.let { it.size() > 0 && it[0].language == "ar" }

    val isArabic: Boolean
        get() = when (choice) {
            "ar" -> true
            "en" -> false
            else -> systemIsArabic
        }

    val layoutDirection: LayoutDirection
        get() = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr

    fun init(context: Context) {
        originalLocale = Locale.getDefault()
        val p = context.getSharedPreferences("language", Context.MODE_PRIVATE).also { prefs = it }
        choice = p.getString("choice", "ar") ?: "ar"
        applyLocale()
    }

    fun choose(value: String) {
        choice = value
        prefs?.edit()?.putString("choice", value)?.apply()
        applyLocale()
    }

    private fun applyLocale() {
        val locale = if (isArabic) {
            Locale.Builder()
                .setLanguage("ar")
                .setUnicodeLocaleKeyword("nu", "latn")
                .build()
        } else {
            originalLocale
        }
        Locale.setDefault(locale)
    }
}
